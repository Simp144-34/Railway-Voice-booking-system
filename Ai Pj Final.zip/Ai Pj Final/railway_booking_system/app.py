import html

import streamlit as st

from services.chatbot_service import (
    BOOKING,
    OPERATION_LABELS,
    RailwayChatbot,
    initial_state,
    operation_label,
    operation_start_message,
)
from services.tts_service import synthesize
from services.booking_service import seats_for_journey


st.set_page_config(
    page_title="မော်လမြိုင်မီးရထားဘူတာ",
    page_icon="🚆",
    layout="centered",
)

st.markdown(
    """
<style>
#MainMenu, footer, header {visibility:hidden}
.block-container {padding-top:1rem; max-width:900px}
.hero {padding:20px; border-radius:18px; margin-bottom:16px; background:#17324d; color:white}
.chat {padding:12px 15px; border-radius:16px; margin:8px 0; white-space:pre-wrap; line-height:1.55}
.bot {background:#f1f4f7; color:#17212b}.user {background:#e1f2ff; color:#102030}
.seat-grid {display:grid; grid-template-columns:repeat(4,minmax(70px,1fr)); gap:8px; margin:10px 0 16px}
.seat {padding:10px 5px; border-radius:10px; text-align:center; font-weight:700; border:1px solid #ddd}
.seat.available {background:#d9f7df; color:#126b2e}
.seat.occupied {background:#ffdede; color:#9b1c1c}
.coach-title {text-align:center; font-weight:700; font-size:1.1rem; margin:0 8px}

</style>
""",
    unsafe_allow_html=True,
)


# ============================================================
# Session state
# ============================================================

if "chat_state" not in st.session_state:
    st.session_state.chat_state = initial_state(BOOKING)

if "messages" not in st.session_state:
    st.session_state.messages = [
        (
            "bot",
            "မင်္ဂလာပါ 👋\n"
            "🚆 မော်လမြိုင်မီးရထားဘူတာ AI Booking Assistantပါ။",
        ),
        ("bot", operation_start_message(BOOKING)),
    ]

if "tts_enabled" not in st.session_state:
    st.session_state.tts_enabled = True


# ============================================================
# Operation selection
# ============================================================

st.markdown(
    "<div class='hero'><h2 style='margin:0'>"
    "🚆 မော်လမြိုင်မီးရထားဘူတာ AI Booking Assistant"
    "</h2></div>",
    unsafe_allow_html=True,
)

operation_options = list(OPERATION_LABELS.keys())
current_operation = st.session_state.chat_state.get("active_operation", BOOKING)

if current_operation not in OPERATION_LABELS.values():
    current_operation = BOOKING

current_label = next(
    label for label, value in OPERATION_LABELS.items()
    if value == current_operation
)

selected_label = st.radio(
    "လုပ်ဆောင်လိုတာကို အရင်ရွေးပါ",
    operation_options,
    index=operation_options.index(current_label),
)

selected_operation = OPERATION_LABELS[selected_label]

# The radio button is the ONLY top-level operation selector.
if selected_operation != st.session_state.chat_state.get("active_operation"):
    old_operation = st.session_state.chat_state.get("active_operation")

    st.session_state.chat_state = initial_state(selected_operation)
    st.session_state.pop("seat_map_coach_index", None)

    st.session_state.messages.append(
        (
            "bot",
            "🔄 Operation ပြောင်းလိုက်ပါပြီ။\n"
            f"အရင်: {operation_label(old_operation)}\n"
            f"အသစ်: {operation_label(selected_operation)}\n\n"
            "အရင် Operation ရဲ့ ယာယီအချက်အလက်တွေကို လုံခြုံစွာရှင်းပြီး "
            "အသစ်ကနေ စတင်ပါမယ်။",
        )
    )
    st.session_state.messages.append(
        ("bot", operation_start_message(selected_operation))
    )

bot = RailwayChatbot(st.session_state.chat_state)

st.info(
    f"Current Operation: {operation_label(selected_operation)}"
)


# ============================================================
# Chat history
# ============================================================

for role, text in st.session_state.messages:
    cls = "user" if role == "user" else "bot"
    st.markdown(
        f"<div class='chat {cls}'>"
        f"{html.escape(text).replace(chr(10), '<br>')}"
        f"</div>",
        unsafe_allow_html=True,
    )



# ============================================================
# Live seat map (Booking -> seat selection step)
# ============================================================

def render_seat_map():
    state = st.session_state.chat_state
    booking = state.get("b", {})
    if selected_operation != BOOKING or state.get("step") != "seats":
        return

    journey_date = booking.get("date")
    class_type = booking.get("class")
    if not journey_date or not class_type:
        return

    try:
        _, rows = seats_for_journey(journey_date, class_type)
    except Exception as exc:
        st.warning(f"ခုံအခြေအနေ ပြသရာတွင် အခက်အခဲရှိပါသည်: {exc}")
        return

    rows = [dict(r) for r in rows]
    coaches = sorted({int(r["coach_number"]) for r in rows})
    if not coaches:
        return

    key = "seat_map_coach_index"
    if key not in st.session_state:
        st.session_state[key] = 0
    st.session_state[key] = max(0, min(st.session_state[key], len(coaches) - 1))

    idx = st.session_state[key]
    coach_no = coaches[idx]

    left, mid, right = st.columns([1, 2, 1])
    with left:
        if st.button("←", key="seat_coach_prev", disabled=idx == 0, use_container_width=True):
            st.session_state[key] -= 1
            st.rerun()
    with mid:
        st.markdown(
            f"<div class='coach-title'>Coach {coach_no}</div>",
            unsafe_allow_html=True,
        )
    with right:
        if st.button("→", key="seat_coach_next", disabled=idx == len(coaches)-1, use_container_width=True):
            st.session_state[key] += 1
            st.rerun()

    coach_rows = [r for r in rows if int(r["coach_number"]) == coach_no]
    for seat_row in sorted({str(r["seat_row"]).upper() for r in coach_rows}):
        row_seats = sorted(
            [r for r in coach_rows if str(r["seat_row"]).upper() == seat_row],
            key=lambda r: int(r["seat_number"]),
        )
        st.markdown(f"**{seat_row} တန်း**")
        cells = []
        for r in row_seats:
            status = "occupied" if r["occupied"] else "available"
            label = f"{r['seat_row']}{r['seat_number']}"
            cells.append(
                f"<div class='seat {status}'>{label}<br>"
                f"{'🔴 မလွတ်' if r['occupied'] else '🟢 လွတ်'}</div>"
            )
        st.markdown(
            "<div class='seat-grid'>" + "".join(cells) + "</div>",
            unsafe_allow_html=True,
        )

    st.caption("🟢 လွတ်   🔴 မလွတ် — ခုံရွေးရန် Chat မှာ Coach 1-A1, A1, B3 စသဖြင့် ရိုက်ပါ။")


render_seat_map()


# ============================================================
# TTS
# ============================================================

st.toggle(
    "🔊 Edge-TTS မြန်မာအသံဖြင့် ဖတ်ပြရန်",
    key="tts_enabled",
)

latest_bot = next(
    (text for role, text in reversed(st.session_state.messages) if role == "bot"),
    "",
)

if st.session_state.tts_enabled and latest_bot:
    try:
        audio_bytes, normalized = synthesize(latest_bot)
        st.audio(audio_bytes, format="audio/mp3")
    except Exception:
        st.warning(
            "🔊 Edge-TTS အသံထုတ်ရာတွင် အခက်အခဲရှိပါသည်။ "
            "Internet connection ကို စစ်ပါ။"
        )


st.caption(
    "💡 Voice input မပါပါ။ Chat မှာ စာရိုက်ပြီး အသံထွက်ကို Edge-TTS ဖြင့် "
    "နားထောင်နိုင်ပါတယ်။"
)


# ============================================================
# Chat input
# ============================================================

typed = st.chat_input("စာရိုက်ပါ…")

if typed:
    st.session_state.messages.append(("user", typed))

    # IMPORTANT:
    # No intent detection is called here to select an operation.
    # RailwayChatbot.handle() uses the radio-selected active_operation.
    replies = bot.handle(typed)

    st.session_state.messages.append(("bot", "\n".join(replies)))
    st.rerun()


# ============================================================
# Controls
# ============================================================

st.divider()

c1, c2 = st.columns(2)

with c1:
    if st.button("♻️ Chat အသစ်", use_container_width=True):
        selected_operation = OPERATION_LABELS[selected_label]
        st.session_state.chat_state = initial_state(selected_operation)
        st.session_state.pop("seat_map_coach_index", None)
        st.session_state.messages = [
            ("bot", operation_start_message(selected_operation))
        ]
        st.rerun()

with c2:
    if st.button("🔇 Voice Off", use_container_width=True):
        st.session_state.tts_enabled = False
        st.rerun()


st.caption(
    "Route: Booking အားလုံး မော်လမြိုင်မှ စတင်ပြီး downstream station များသို့သာ "
    "သွားနိုင်ပါသည်။"
)
