# Railway Booking System — Chatbot Edition

## Project behavior
- Booking Form ကို မသုံးဘဲ Chatbot တစ်ခုတည်းနဲ့ Booking / Cancel / Check / Inquiry ကို ဆောင်ရွက်နိုင်သည်။
- Chatbot သည် မေးခွန်းများကို text ဖြင့်ပြပြီး browser voice ဖြင့်လည်း ဖတ်ပြနိုင်သည်။
- User သည် text သီးသန့် ဖြင့်သာ ဖြေနိုင်သည်။
- Booking နှင့် Cancellation နှစ်ခုလုံးကို Chatbot တစ်ခုတည်းတွင် ဆောင်ရွက်သည်။
- Booking origin သည် **မော်လမြိုင်တစ်ခုတည်း** ဖြစ်ရမည်။
- Destination သည် downstream stations: **ပေါင်, သထုံ, ကျိုက်ထို, သိမ်ဇရပ်, ပဲခူး, တိုးကြောင်ကလေး, ရန်ကုန်** သာဖြစ်သည်။
- Fare သည် **မော်လမြိုင် → destination** အလိုက် class-based fare ဖြစ်သည်။
- Intermediate station မှ booking စတင်ခြင်း မပြုလုပ်နိုင်ပါ။
- Booking window သည် ယနေ့မှ ၇ ရက်အတွင်းဖြစ်သည်။
- တစ်ကြိမ်လျှင် အများဆုံး ၈ ခုံ booking လုပ်နိုင်သည်။
- Database တွင် passenger table / passenger_id မလိုဘဲ booking table ထဲတွင် name/phone သိမ်းထားသည်။

## Booking conversation
`Operation → Booking → Date → Destination → Class → Seat count → Live seat availability → Seat selection → Name → Phone → Summary → Confirm → Booking ID`

## Cancellation conversation
`Cancel → Booking ID → Booking details → Confirm cancellation → Seats released`

## Run on Windows PowerShell
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python database\seed_data.py
streamlit run app.py
```

## Voice
- Voice input မပါပါ။ User သည် text input ဖြင့်သာ command ပေးရမည်။
- Voice output: Myanmar text normalization ပြုလုပ်ပြီး `edge-tts` (`my-MM-NilarNeural`) ဖြင့် MP3 ထုတ်ပေးသည်။
- `q.json` သည် inquiry knowledge source ဖြစ်ပြီး schedule, fare, duration, VIP, food service, station arrival times ကို ဖြေသည်.

## Main files
- `app.py` — single chatbot UI, text + voice input/output
- `services/chatbot_service.py` — booking/cancel conversation state machine
- `services/booking_service.py` — database booking, fare, seats, cancellation
- `database/schema.sql` — SQLite schema
- `database/seed_data.py` — initial train/station/fare/coach/seat data
- `database/railway.db` — included database


## Operation routing
1. Booking
2. Cancel (Booking ID required)
3. Check (Booking ID required)
4. Inquiry (`q.json`)

Seat selection refreshes current DB occupancy on every selection and confirmation, and the database unique index prevents double-selling a confirmed seat for the same journey.


## Operation routing
1. Booking
2. Cancel (Booking ID required)
3. Check (Booking ID required)
4. Inquiry (`q.json`)

Seat selection refreshes current DB occupancy on every selection and confirmation, and the database unique index prevents double-selling a confirmed seat for the same journey.
