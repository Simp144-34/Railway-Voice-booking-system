from pathlib import Path
import sqlite3
ROOT=Path(__file__).resolve().parents[1]; DB=ROOT/'database'/'railway.db'; SCHEMA=ROOT/'database'/'schema.sql'
STATIONS=[('ML','မော်လမြိုင်'),('PAUNG','ပေါင်'),('THT','သထုံ'),('KTO','ကျိုက်ထို'),('THZ','သိမ်ဇရပ်'),('BGO','ပဲခူး'),('TKK','တိုးကြောင်ကလေး'),('YGN','ရန်ကုန်')]
STOPS=[('ML','12:00 PM','12:00 PM'),('PAUNG','12:42 PM','12:44 PM'),('THT','1:22 PM','1:24 PM'),('KTO','2:41 PM','2:43 PM'),('THZ','3:35 PM','3:37 PM'),('BGO','4:45 PM','4:47 PM'),('TKK','5:35 PM','5:37 PM'),('YGN','6:00 PM','6:00 PM')]
PRICES={'ပေါင်':(2000,3000),'သထုံ':(4000,5000),'ကျိုက်ထို':(7000,10000),'သိမ်ဇရပ်':(9000,13000),'ပဲခူး':(12000,17000),'တိုးကြောင်ကလေး':(15000,21000),'ရန်ကုန်':(16000,22000)}
c=sqlite3.connect(DB); c.execute('PRAGMA foreign_keys=ON'); c.executescript(SCHEMA.read_text(encoding='utf-8'))
if c.execute('SELECT COUNT(*) FROM trains').fetchone()[0]==0: c.execute('INSERT INTO trains(train_name) VALUES(?)',('DEMU',))
if c.execute('SELECT COUNT(*) FROM stations').fetchone()[0]==0: c.executemany('INSERT INTO stations(station_code,station_name) VALUES(?,?)',STATIONS)
train_id=c.execute('SELECT train_id FROM trains LIMIT 1').fetchone()[0]; st={r[1]:r[0] for r in c.execute('SELECT station_id,station_code FROM stations')}
if c.execute('SELECT COUNT(*) FROM schedules').fetchone()[0]==0: c.execute('INSERT INTO schedules(train_id,train_number,from_station_id,to_station_id,departure_time,arrival_time) VALUES(?,?,?,?,?,?)',(train_id,'84',st['ML'],st['YGN'],'12:00 PM','6:00 PM'))
sid=c.execute('SELECT schedule_id FROM schedules LIMIT 1').fetchone()[0]
if c.execute('SELECT COUNT(*) FROM schedule_stops').fetchone()[0]==0:
    c.executemany('INSERT INTO schedule_stops(schedule_id,station_id,stop_order,arrival_time,departure_time) VALUES(?,?,?,?,?)',[(sid,st[code],i,a,d) for i,(code,a,d) in enumerate(STOPS,1)])
if c.execute('SELECT COUNT(*) FROM fares').fetchone()[0]==0:
    for name,(p1,p2) in PRICES.items():
        did=c.execute('SELECT station_id FROM stations WHERE station_name=?',(name,)).fetchone()[0]
        c.execute('INSERT INTO fares(train_id,from_station_id,to_station_id,class_type,price) VALUES(?,?,?,?,?)',(train_id,st['ML'],did,'ပထမတန်း',p1)); c.execute('INSERT INTO fares(train_id,from_station_id,to_station_id,class_type,price) VALUES(?,?,?,?,?)',(train_id,st['ML'],did,'အထက်တန်း',p2))
if c.execute('SELECT COUNT(*) FROM coaches').fetchone()[0]==0:
    for n in range(1,5):
        cid=c.execute('INSERT INTO coaches(train_id,coach_number,class_type) VALUES(?,?,?)',(train_id,n,'ပထမတန်း')).lastrowid
        for row in 'ABCD':
            for num in range(1,(13 if n in (1,4) else 15)+1): c.execute('INSERT INTO seats(coach_id,seat_row,seat_number) VALUES(?,?,?)',(cid,row,num))
    for n in range(5,7):
        cid=c.execute('INSERT INTO coaches(train_id,coach_number,class_type) VALUES(?,?,?)',(train_id,n,'အထက်တန်း')).lastrowid
        for row in 'ABC':
            for num in range(1,13): c.execute('INSERT INTO seats(coach_id,seat_row,seat_number) VALUES(?,?,?)',(cid,row,num))
c.commit(); c.close(); print('Database seeded:',DB)
