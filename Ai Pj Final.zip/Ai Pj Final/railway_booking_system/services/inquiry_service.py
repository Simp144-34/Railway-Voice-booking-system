import json
from pathlib import Path

# UI labels and their internal operation values.
# The UI is the only source allowed to select the top-level operation.
OPERATION_LABELS = {
    "🎫 Booking လုပ်မယ်": "BOOKING",
    "❌ Booking Cancel လုပ်မယ်": "CANCEL_BOOKING",
    "🔎 Booking စစ်မယ်": "CHECK_BOOKING",
    "❓ ရထားအကြောင်း မေးမယ်": "TRAIN_INFO",
}

ROOT = Path(__file__).resolve().parents[1]
Q_FILE = ROOT / "q.json"


def load_questions():
    with Q_FILE.open("r", encoding="utf-8") as f:
        return json.load(f)["inquiry_service"]


def _norm(text):
    return text.strip().lower().translate(str.maketrans("၀၁၂၃၄၅၆၇၈၉", "0123456789"))


def _destination(text, data):
    t = _norm(text)
    aliases = {
        "ပေါင်": "ပေါင်", "paung": "ပေါင်",
        "သထုံ": "သထုံ", "thaton": "သထုံ",
        "ကျိုက်ထို": "ကျိုက်ထို", "kyaikto": "ကျိုက်ထို", "kyaikhto": "ကျိုက်ထို",
        "သိမ်ဇရပ်": "သိမ်ဇရပ်", "thein za yat": "သိမ်ဇရပ်", "thein zayat": "သိမ်ဇရပ်",
        "ပဲခူး": "ပဲခူး", "bago": "ပဲခူး",
        "တိုးကြောင်ကလေး": "တိုးကြောင်ကလေး", "toe kyaung kalay": "တိုးကြောင်ကလေး", "toe kyaung": "တိုးကြောင်ကလေး",
        "ရန်ကုန်": "ရန်ကုန်", "yangon": "ရန်ကုန်",
    }
    for key, value in aliases.items():
        if key in t and value in data["route"]:
            return value
    return None


def _class(text):
    t = _norm(text)
    if any(x in t for x in ("ပထမ", "first", "1st")):
        return "ပထမတန်း"
    if any(x in t for x in ("အထက်", "upper", "second", "2nd")):
        return "အထက်တန်း"
    return None


def _matches(text, examples):
    t = _norm(text)
    return any(_norm(x) in t for x in examples)


def answer(text):
    """Answer supported railway questions using q.json as the single inquiry knowledge source."""
    data = load_questions()
    t = _norm(text)

    # More specific categories first.
    if _matches(t, data["station_arrival_times"]["question_examples"]):
        dest = _destination(t, data)
        if dest:
            for stop in data["station_arrival_times"]["stops"]:
                if stop["station"] == dest:
                    return f"🚉 {dest} သို့ {stop['arrival']} တွင် ရောက်ရှိပြီး {stop['departure']} တွင် ထွက်ခွာပါသည်။"
        lines = [data["station_arrival_times"]["answer"]]
        for stop in data["station_arrival_times"]["stops"]:
            lines.append(f"• {stop['station']} — ရောက် {stop['arrival']} | ထွက် {stop['departure']}")
        return "\n".join(lines)

    if _matches(t, data["fares"]["question_examples"]):
        dest = _destination(t, data)
        if dest:
            f = data["fares"]["fares"].get(dest, {})
            cls = _class(t)
            if cls and cls in f:
                return f"💰 မော်လမြိုင် → {dest} ({cls}) လက်မှတ်ခ {f[cls]:,} ကျပ် ဖြစ်ပါသည်။"
            return f"💰 မော်လမြိုင် → {dest}\nပထမတန်း — {f.get('ပထမတန်း', 0):,} ကျပ်\nအထက်တန်း — {f.get('အထက်တန်း', 0):,} ကျပ်"
        return "💰 လက်မှတ်ခများသည် မော်လမြိုင်မှ destination အလိုက် ကွာခြားပါသည်။\n" + "\n".join(
            f"• {name}: ပထမတန်း {vals['ပထမတန်း']:,} | အထက်တန်း {vals['အထက်တန်း']:,} ကျပ်"
            for name, vals in data["fares"]["fares"].items()
        )

    if _matches(t, data["travel_duration"]["question_examples"]):
        return data["travel_duration"]["answer"]

    if _matches(t, data["vip_service"]["question_examples"]):
        return data["vip_service"]["answer"]

    if _matches(t, data["food_service"]["question_examples"]):
        return data["food_service"]["answer"]

    if _matches(t, data["train_schedule"]["question_examples"]):
        return data["train_schedule"]["answer"]

    return None


def operation_prompt():
    return (
        "လုပ်ဆောင်လိုတာကို အပေါ်က Operation ကို ရွေးပေးပါ။\n"
        + "\n".join(OPERATION_LABELS.keys())
    )
