from datetime import date, timedelta
from pathlib import Path
import secrets
import sqlite3
import string

ROOT = Path(__file__).resolve().parents[1]
DB = ROOT / "database" / "railway.db"
CLASS_FIRST = "ပထမတန်း"
CLASS_UPPER = "အထက်တန်း"
ORIGIN_NAME = "မော်လမြိုင်"


def connect():
    c = sqlite3.connect(DB, timeout=10)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    # Small migration so an existing copy of railway.db also works.
    cols = {r[1] for r in c.execute("PRAGMA table_info(bookings)").fetchall()}
    if "destination_station_id" not in cols:
        c.execute("ALTER TABLE bookings ADD COLUMN destination_station_id INTEGER")
        c.commit()
    return c


def booking_window():
    today = date.today()
    return today, today + timedelta(days=7)


def stations():
    with connect() as c:
        return c.execute("SELECT * FROM stations ORDER BY station_id").fetchall()


def allowed_destinations():
    with connect() as c:
        return c.execute(
            """SELECT s.station_id, s.station_code, s.station_name
               FROM stations s
               JOIN schedule_stops ss ON ss.station_id=s.station_id
               WHERE ss.schedule_id=(SELECT schedule_id FROM schedules LIMIT 1)
                 AND ss.stop_order > (SELECT stop_order FROM schedule_stops
                                      WHERE schedule_id=ss.schedule_id
                                        AND station_id=(SELECT station_id FROM stations WHERE station_code='ML'))
               ORDER BY ss.stop_order"""
        ).fetchall()


def trip_times(destination_id):
    """Return the fixed Mawlamyine departure and the selected destination arrival time."""
    with connect() as c:
        row = c.execute(
            """SELECT os.departure_time AS departure_time,
                      ds.arrival_time AS arrival_time
               FROM schedules sc
               JOIN schedule_stops os ON os.schedule_id=sc.schedule_id
               JOIN schedule_stops ds ON ds.schedule_id=sc.schedule_id
               WHERE os.station_id=(SELECT station_id FROM stations WHERE station_code='ML')
                 AND ds.station_id=?
               ORDER BY sc.schedule_id
               LIMIT 1""",
            (destination_id,),
        ).fetchone()
        if not row:
            raise ValueError("ခရီးစဉ်အချိန် မတွေ့ပါ။")
        return row["departure_time"], row["arrival_time"]


def fare(destination_id, class_type):
    # Project rule: every fare must start from Mawlamyine (station_id/code ML).
    with connect() as c:
        r = c.execute(
            """SELECT f.price
               FROM fares f
               JOIN stations s ON s.station_id=f.from_station_id
               WHERE s.station_code='ML' AND f.to_station_id=? AND f.class_type=?
               LIMIT 1""",
            (destination_id, class_type),
        ).fetchone()
        return float(r["price"]) if r else None


def coaches_for_class(class_type):
    with connect() as c:
        return c.execute(
            "SELECT * FROM coaches WHERE class_type=? ORDER BY coach_number",
            (class_type,),
        ).fetchall()


def ensure_journey(c, journey_date):
    s = c.execute("SELECT schedule_id FROM schedules ORDER BY schedule_id LIMIT 1").fetchone()
    if not s:
        raise ValueError("Schedule မရှိပါ။")
    c.execute(
        "INSERT OR IGNORE INTO journeys(schedule_id,journey_date) VALUES(?,?)",
        (s["schedule_id"], journey_date),
    )
    return c.execute(
        "SELECT journey_id FROM journeys WHERE schedule_id=? AND journey_date=?",
        (s["schedule_id"], journey_date),
    ).fetchone()["journey_id"]


def seats_for_journey(journey_date, class_type):
    with connect() as c:
        jid = ensure_journey(c, journey_date)
        c.commit()
        rows = c.execute(
            """SELECT se.seat_id, se.seat_row, se.seat_number,
                      co.coach_number,
                      EXISTS(
                        SELECT 1 FROM bookings b
                        WHERE b.journey_id=? AND b.seat_id=se.seat_id
                          AND b.booking_status='CONFIRMED'
                      ) AS occupied
               FROM seats se
               JOIN coaches co ON co.coach_id=se.coach_id
               WHERE co.class_type=?
               ORDER BY co.coach_number,se.seat_row,se.seat_number""",
            (jid, class_type),
        ).fetchall()
        return jid, rows



def seat_availability(journey_date, class_type):
    """Return current live seat status; every call queries confirmed bookings."""
    return seats_for_journey(journey_date, class_type)[1]

def validate_customer(name, phone):
    if not name or len(name.strip()) < 2:
        raise ValueError("အမည်ကို မှန်ကန်စွာ ထည့်/ပြောပေးပါ။")
    digits = "".join(ch for ch in phone if ch.isdigit())
    if len(digits) < 8:
        raise ValueError("ဖုန်းနံပါတ် မမှန်ပါ။")
    clean_phone = "".join(ch for ch in phone if ch.isdigit() or ch == "+")
    return name.strip(), clean_phone


def make_reference():
    return "MLY-" + "".join(secrets.choice(string.ascii_uppercase + string.digits) for _ in range(8))


def create_booking(journey_date, destination_id, class_type, seat_ids, name, phone):
    if not seat_ids:
        raise ValueError("ခုံအနည်းဆုံး ၁ ခုံရွေးပါ။")
    today, maxday = booking_window()
    d = date.fromisoformat(journey_date)
    if d < today or d > maxday:
        raise ValueError("Booking ကို ယနေ့မှ ၇ ရက်အတွင်းအတွက်သာ ပြုလုပ်နိုင်ပါတယ်။")

    # Destination must be a downstream stop from Mawlamyine.
    allowed = {r["station_id"] for r in allowed_destinations()}
    if destination_id not in allowed:
        raise ValueError("မော်လမြိုင်မှ downstream station မဟုတ်သော ဘူတာကို Booking မလုပ်နိုင်ပါ။")

    name, phone = validate_customer(name, phone)
    with connect() as c:
        jid = ensure_journey(c, journey_date)
        unique_ids = list(dict.fromkeys(seat_ids))
        q = ",".join("?" * len(unique_ids))
        rows = c.execute(
            f"""SELECT se.seat_id, co.class_type, co.coach_number,
                       se.seat_row, se.seat_number
                FROM seats se JOIN coaches co ON co.coach_id=se.coach_id
                WHERE se.seat_id IN ({','.join('?' * len(unique_ids))})""",
            tuple(unique_ids),
        ).fetchall()
        if len(rows) != len(unique_ids):
            raise ValueError("ရွေးထားသောခုံအချို့ မရှိပါ။")
        if any(r["class_type"] != class_type for r in rows):
            raise ValueError("ရွေးထားသောခုံများသည် Class မကိုက်ပါ။")
        occupied = c.execute(
            f"""SELECT seat_id FROM bookings
                WHERE journey_id=? AND booking_status='CONFIRMED'
                  AND seat_id IN ({q}) LIMIT 1""",
            (jid, *unique_ids),
        ).fetchone()
        if occupied:
            raise ValueError("ရွေးထားသောခုံအချို့ကို အခြားသူယူပြီးသားပါ။ ခုံများကို ပြန်ရွေးပါ။")

        ref = make_reference()
        try:
            for sid in unique_ids:
                c.execute(
                    """INSERT INTO bookings
                       (booking_reference,journey_id,seat_id,destination_station_id,full_name,phone,booking_status)
                       VALUES(?,?,?,?,?,?,'CONFIRMED')""",
                    (ref, jid, sid, destination_id, name, phone),
                )
            c.commit()
        except sqlite3.IntegrityError:
            c.rollback()
            raise ValueError("ခုံရောင်းချမှု တစ်ချိန်တည်းဖြစ်နေပါသည်။ ခုံများကို ပြန်ရွေးပါ။")

        total = (fare(destination_id, class_type) or 0) * len(rows)
        return ref, rows, total


def find_booking(ref):
    with connect() as c:
        return c.execute(
            """SELECT b.*, j.journey_date, se.seat_row, se.seat_number,
                      co.coach_number, co.class_type,
                      ds.station_name AS destination,
                      sc.departure_time AS departure_time,
                      dst.arrival_time AS arrival_time
               FROM bookings b
               JOIN journeys j ON j.journey_id=b.journey_id
               JOIN schedules sc ON sc.schedule_id=j.schedule_id
               JOIN seats se ON se.seat_id=b.seat_id
               JOIN coaches co ON co.coach_id=se.coach_id
               JOIN stations ds ON ds.station_id=b.destination_station_id
               JOIN schedule_stops dst
                 ON dst.schedule_id=sc.schedule_id
                AND dst.station_id=b.destination_station_id
               WHERE b.booking_reference=?
               ORDER BY b.booking_id""",
            (ref.strip().upper(),),
        ).fetchall()


def cancel_booking(ref):
    ref = ref.strip().upper()
    with connect() as c:
        n = c.execute(
            "SELECT COUNT(*) n FROM bookings WHERE booking_reference=? AND booking_status='CONFIRMED'",
            (ref,),
        ).fetchone()["n"]
        if not n:
            raise ValueError("Booking ID/Reference မတွေ့ပါ သို့မဟုတ် Cancel လုပ်ပြီးသားပါ။")
        c.execute(
            """UPDATE bookings SET booking_status='CANCELLED', cancelled_at=CURRENT_TIMESTAMP
               WHERE booking_reference=? AND booking_status='CONFIRMED'""",
            (ref,),
        )
        c.commit()
        return n
