import re


# ============================================================
# Myanmar TTS normalization
# ============================================================

MONTHS_MM = {
    "January": "ဇန်နဝါရီလ",
    "February": "ဖေဖော်ဝါရီလ",
    "March": "မတ်လ",
    "April": "ဧပြီလ",
    "May": "မေလ",
    "June": "ဇွန်လ",
    "July": "ဇူလိုင်လ",
    "August": "ဩဂုတ်လ",
    "September": "စက်တင်ဘာလ",
    "October": "အောက်တိုဘာလ",
    "November": "နိုဝင်ဘာလ",
    "December": "ဒီဇင်ဘာလ",
}

ONES = {
    0: "",
    1: "တစ်",
    2: "နှစ်",
    3: "သုံး",
    4: "လေး",
    5: "ငါး",
    6: "ခြောက်",
    7: "ခုနစ်",
    8: "ရှစ်",
    9: "ကိုး",
}

TEENS = {
    10: "ဆယ်",
    11: "ဆယ့်တစ်",
    12: "ဆယ့်နှစ်",
    13: "ဆယ့်သုံး",
    14: "ဆယ့်လေး",
    15: "ဆယ့်ငါး",
    16: "ဆယ့်ခြောက်",
    17: "ဆယ့်ခုနစ်",
    18: "ဆယ့်ရှစ်",
    19: "ဆယ့်ကိုး",
}

TENS = {
    20: "နှစ်ဆယ်",
    30: "သုံးဆယ်",
    40: "လေးဆယ်",
    50: "ငါးဆယ်",
    60: "ခြောက်ဆယ်",
    70: "ခုနစ်ဆယ်",
    80: "ရှစ်ဆယ်",
    90: "ကိုးဆယ်",
}




# ============================================================
# English alphabet pronunciation for Myanmar TTS
# ============================================================

ALPHABET_TO_MM = {
    "A": "အေ", "B": "ဘီ", "C": "စီ", "D": "ဒီ", "E": "အီး",
    "F": "အက်ဖ်", "G": "ဂျီ", "H": "အိတ်ချ်", "I": "အိုင်",
    "J": "ဂျေ", "K": "ကေ", "L": "အယ်လ်", "M": "အမ်",
    "N": "အန်", "O": "အို", "P": "ပီ", "Q": "ကျူ",
    "R": "အာ", "S": "အက်စ်", "T": "တီ", "U": "ယူ",
    "V": "ဗီ", "W": "ဒဗလျူ", "X": "အက်စ်", "Y": "ဝိုင်",
    "Z": "ဇက်",
}


def normalize_alphabet_for_tts(text):
    """
    Convert English alphabet characters that are used as standalone
    letters or railway seat-row identifiers (A1, B3, Coach 5-A1)
    into Myanmar pronunciation.

    English words are intentionally left alone; railway terminology
    is normalized separately before this function is called.
    """
    def replace(match):
        return ALPHABET_TO_MM[match.group(1).upper()]

    # Only convert a letter when it is a standalone token or is
    # directly attached to a seat number. This avoids changing words
    # such as "Coach" or "Booking".
    return re.sub(r"(?<![A-Za-z])([A-Za-z])(?=\d|\b)", replace, text)


# ============================================================
# Number conversion
# ============================================================

def number_under_1000(n):
    if n == 0:
        return ""

    if n < 10:
        return ONES[n]

    if 10 <= n <= 19:
        return TEENS[n]

    if n < 100:
        tens = (n // 10) * 10
        ones = n % 10

        if ones == 0:
            return TENS[tens]

        return TENS[tens].replace("ဆယ်", "ဆယ့်") + ONES[ones]

    hundreds = n // 100
    remainder = n % 100

    result = "တစ်ရာ" if hundreds == 1 else ONES[hundreds] + "ရာ"

    if remainder:
        result += number_under_1000(remainder)

    return result


def number_to_myanmar(n):
    try:
        n = int(n)
    except (ValueError, TypeError):
        return str(n)

    if n == 0:
        return "သုည"

    if n < 0:
        return "အနှုတ် " + number_to_myanmar(abs(n))

    parts = []

    if n >= 1_000_000:
        million = n // 1_000_000
        parts.append(number_to_myanmar(million) + "သန်း")
        n %= 1_000_000

    if n >= 100_000:
        hundred_thousand = n // 100_000
        parts.append(
            "တစ်သိန်း"
            if hundred_thousand == 1
            else ONES[hundred_thousand] + "သိန်း"
        )
        n %= 100_000

    if n >= 10_000:
        ten_thousand = n // 10_000
        parts.append(
            "တစ်သောင်း"
            if ten_thousand == 1
            else ONES[ten_thousand] + "သောင်း"
        )
        n %= 10_000

    if n >= 1_000:
        thousand = n // 1_000
        parts.append(
            "တစ်ထောင်"
            if thousand == 1
            else ONES[thousand] + "ထောင်"
        )
        n %= 1_000

    if n:
        parts.append(number_under_1000(n))

    return "".join(parts)




def phone_number_to_speech(phone_number):
    """
    Read a phone number digit-by-digit.
    Never use place-value conversion (သိန်း/သောင်း/ထောင်) for phone numbers.
    """
    digit_words = {
        "0": "ဇီရိုး", "1": "ဝမ်း", "2": "တူး", "3": "သရီး", "4": "ဖိုး",
        "5": "ဖိုင်းဗ်", "6": "ဆစ်", "7": "ဆဲဗင်း", "8": "အိတ်", "9": "နိုင်း",
    }
    value = str(phone_number).strip()
    return " ".join(digit_words[ch] for ch in value if ch.isdigit())


BOOKING_ID_SPEECH = {
    **ALPHABET_TO_MM,
    "0": "ဇီရိုး", "1": "ဝမ်း", "2": "တူး", "3": "သရီး", "4": "ဖိုး",
    "5": "ဖိုင်းဗ်", "6": "ဆစ်", "7": "ဆဲဗင်း", "8": "အိတ်", "9": "နိုင်း",
}


def booking_id_to_speech(value):
    """Read booking IDs character-by-character for Myanmar TTS."""
    value = str(value).strip().upper()
    spoken = []
    for ch in value:
        if ch in BOOKING_ID_SPEECH:
            spoken.append(BOOKING_ID_SPEECH[ch])
        elif ch == "-":
            spoken.append("-")
        else:
            spoken.append(ch)
    return " ".join(spoken)


def prepare_booking_ids_for_tts(text):
    """Protect Booking ID values and replace them with character-by-character speech."""
    pattern = re.compile(r"\bMLY-[A-Z0-9]{8}\b", re.I)
    placeholders = {}

    def repl(match):
        token = f"__BOOKING_ID_{len(placeholders)}__"
        placeholders[token] = booking_id_to_speech(match.group(0))
        return token

    value = pattern.sub(repl, str(text))
    for token, spoken in placeholders.items():
        value = value.replace(token, spoken)
    return value


# ============================================================
# Identifier protection
# ============================================================

def protect_identifiers(text):
    """
    Protect identifier VALUES, not their English labels.

    This lets us turn:
        Train 84 -> ရထား 84
        Seat A-6 -> ထိုင်ခုံ A-6
        Booking ID MLY-AB12345678 -> လက်မှတ်နံပါတ် MLY-AB12345678

    while preventing the identifier itself from being numerically changed.
    """
    protected = {}

    patterns = [
        # Booking IDs
        r"\bMLY-[A-Z0-9]{8}\b",

        # Coach / seat value after a railway label.
        r"(?<=\bCoach\s)\d+\s*[-/]\s*[A-Da-d]\s*[-]?\s*\d{1,2}\b",
        r"(?<=\bSeat\s)[A-Da-d]\s*[-]?\s*\d{1,2}\b",
        r"(?<=\bCoach\sNumber\s)\d+\b",
        r"(?<=\bSeat\sNumber\s)[A-Da-d0-9-]+\b",
        r"(?<=\bTrain\sNumber\s)[A-Z0-9-]+\b",
        r"(?<=\bTrain\s)\d+\b",

        # Common station codes.
        r"\b(?:MLY|YGN|BGO|KTO|THN|PGE|TKK|TZY)\b",

        # Generic mixed alphanumeric identifier.
        r"\b(?=[A-Z0-9-]{4,}\b)(?=[A-Z0-9-]*[A-Z])(?=[A-Z0-9-]*\d)[A-Z0-9-]+\b",
    ]

    # Python lookbehind must be fixed-width. Use a combined explicit
    # scanner instead of variable-length lookbehinds.
    value_patterns = [
        re.compile(r"\bMLY-[A-Z0-9]{8}\b", re.I),
        re.compile(r"\bCoach\s+(\d+\s*[-/]\s*[A-Da-d]\s*[-]?\s*\d{1,2})\b", re.I),
        re.compile(r"\bSeat\s+([A-Da-d]\s*[-]?\s*\d{1,2})\b", re.I),
        re.compile(r"\bCoach\s+Number\s+(\d+)\b", re.I),
        re.compile(r"\bSeat\s+Number\s+([A-Da-d0-9-]+)\b", re.I),
        re.compile(r"\bTrain\s+Number\s+([A-Z0-9-]+)\b", re.I),
        re.compile(r"\bTrain\s+(\d+)\b", re.I),
        re.compile(r"\b(?:MLY|YGN|BGO|KTO|THN|PGE|TKK|TZY)\b", re.I),
        re.compile(
            r"\b(?=[A-Z0-9-]{4,}\b)(?=[A-Z0-9-]*[A-Z])"
            r"(?=[A-Z0-9-]*\d)[A-Z0-9-]+\b",
            re.I,
        ),
    ]

    # Replace from right to left so earlier positions remain valid.
    matches = []
    for pattern in value_patterns:
        for match in pattern.finditer(text):
            value = match.group(1) if match.lastindex else match.group(0)
            start_pos = match.start(1) if match.lastindex else match.start()
            end_pos = match.end(1) if match.lastindex else match.end()
            matches.append((start_pos, end_pos, value))

    selected = []
    for start_pos, end_pos, value in sorted(matches, key=lambda x: (x[0], -(x[1] - x[0]))):
        if any(start_pos < e and end_pos > s for s, e, _ in selected):
            continue
        selected.append((start_pos, end_pos, value))

    for start_pos, end_pos, value in reversed(selected):
        token = f"__PROTECTED_{len(protected)}__"
        protected[token] = value
        text = text[:start_pos] + token + text[end_pos:]

    return text, protected


def restore_identifiers(text, protected):
    for token, value in protected.items():
        text = text.replace(token, value)
    return text


# ============================================================
# Railway terminology
# ============================================================

def normalize_railway_terms(text):
    replacements = [
        # Specific phrases first.
        (r"\bCancel\s+Booking\b", "လက်မှတ်ဖျက်သိမ်းခြင်း"),
        (r"\bCheck\s+Booking\b", "လက်မှတ်စစ်ဆေးခြင်း"),
        (r"\bBooking\s+Check\b", "လက်မှတ်စစ်ဆေးခြင်း"),
        (r"\bBooking\s+ID\b", "လက်မှတ်နံပါတ်"),
        (r"\bBooking\s+Reference\b", "လက်မှတ်နံပါတ်"),
        (r"\bBooking\b", "ဘွတ်ကင်"),
        (r"\bTrain\s+Number\b", "ရထားအမှတ်"),
        (r"\bTrain\b", "ရထား"),
        (r"\bRailway\b", "မီးရထား"),
        (r"\bStation\b", "ဘူတာ"),
        (r"\bDeparture\s+Time\b", "ထွက်ခွာချိန်"),
        (r"\bArrival\s+Time\b", "ရောက်ရှိချိန်"),
        (r"\bDeparture\b", "ထွက်ခွာမည့်"),
        (r"\bDestination\b", "သွားမည့်နေရာ"),
        (r"\bCoach\s+Number\b", "ရထားတွဲအမှတ်"),
        (r"\bCoach\b", "ရထားတွဲ"),
        (r"\bSeat\s+Number\b", "ထိုင်ခုံအမှတ်"),
        (r"\bSeat\b", "ထိုင်ခုံ"),
        (r"\bClass\b", "အတန်း"),
        (r"\bVIP\s+Class\b", "အထူးတန်း"),
        (r"\bNormal\s+Class\b", "ရိုးရိုးတန်း"),
        (r"\bTicket\b", "လက်မှတ်"),
        (r"\bPrice\b", "စျေးနှုန်း"),
        (r"\bAvailable\b", "ရရှိနိုင်သည်"),
        (r"\bUnavailable\b", "မရရှိနိုင်ပါ"),
        (r"\bConfirmation\b", "အတည်ပြုချက်"),
        (r"\bConfirm\b", "အတည်ပြုသည်"),
        (r"\bTravel\s+Date\b", "ခရီးသွားမည့်ရက်"),
        (r"\bFrom\b", "မှ"),
        (r"\bTo\b", "သို့"),
        (r"\bDate\b", "ရက်စွဲ"),
        (r"\bTime\b", "အချိန်"),
        (r"\bFare\b", "ခရီးစဉ်"),
    ]

    for pattern, replacement in replacements:
        text = re.sub(pattern, replacement, text, flags=re.I)

    return text


# ============================================================
# Date / month
# ============================================================

def normalize_date(text):
    """Convert common date formats into natural Myanmar speech.

    Supports both DD/MM/YYYY and DD-MM-YYYY so every booking result
    uses the same date-specific TTS path. ISO YYYY-MM-DD is also handled.
    """
    patterns = (
        # DD/MM/YYYY or DD-MM-YYYY
        (re.compile(r"\b(\d{1,2})[/-](\d{1,2})[/-](\d{4})\b"), False),
        # YYYY-MM-DD or YYYY/MM/DD
        (re.compile(r"\b(\d{4})[/-](\d{1,2})[/-](\d{1,2})\b"), True),
    )

    def replace_date(match, iso=False):
        if iso:
            year = int(match.group(1))
            month = int(match.group(2))
            day = int(match.group(3))
        else:
            day = int(match.group(1))
            month = int(match.group(2))
            year = int(match.group(3))

        months = {
            1: "ဇန်နဝါရီလ",
            2: "ဖေဖော်ဝါရီလ",
            3: "မတ်လ",
            4: "ဧပြီလ",
            5: "မေလ",
            6: "ဇွန်လ",
            7: "ဇူလိုင်လ",
            8: "ဩဂုတ်လ",
            9: "စက်တင်ဘာလ",
            10: "အောက်တိုဘာလ",
            11: "နိုဝင်ဘာလ",
            12: "ဒီဇင်ဘာလ",
        }

        if month not in months:
            return match.group(0)

        return (
            f"{number_to_myanmar(day)} ရက် "
            f"{months[month]} "
            f"{number_to_myanmar(year)} ခုနှစ်"
        )

    value = str(text)
    for pattern, iso in patterns:
        value = pattern.sub(lambda m: replace_date(m, iso), value)
    return value


def normalize_month_names(text):
    for month_en, month_mm in MONTHS_MM.items():
        text = re.sub(
            rf"\b{month_en}\b",
            month_mm,
            text,
            flags=re.I,
        )
    return text


# ============================================================
# Time / AM-PM
# ============================================================

def normalize_time(text):
    """
    10:30 AM -> မနက် ဆယ်နာရီ မိနစ်သုံးဆယ်
    8:05 PM  -> ညနေ ရှစ်နာရီ မိနစ်ငါး
    """
    pattern = r"\b(\d{1,2}):(\d{2})\s*(AM|PM)\b"

    def replace_time(match):
        hour = int(match.group(1))
        minute = int(match.group(2))
        period = match.group(3).upper()

        period_mm = "မနက်" if period == "AM" else "ညနေ"
        hour_mm = number_to_myanmar(hour)

        if minute == 0:
            return f"{period_mm} {hour_mm}နာရီ"

        return (
            f"{period_mm} {hour_mm}နာရီ "
            f"{number_to_myanmar(minute)}မိနစ်"
        )

    return re.sub(pattern, replace_time, text, flags=re.I)


def normalize_ampm(text):
    text = re.sub(r"\bAM\b", "မနက်", text, flags=re.I)
    text = re.sub(r"\bPM\b", "ညနေ", text, flags=re.I)
    return text


# ============================================================
# Currency
# ============================================================

def normalize_currency(text):
    pattern = r"(?<!\w)(\d[\d,]*)\s*(ကျပ်|MMK|Ks\.?)(?!\w)"

    def replace_currency(match):
        raw_number = match.group(1).replace(",", "")

        try:
            amount = int(raw_number)
        except ValueError:
            return match.group(0)

        return f"{number_to_myanmar(amount)} ကျပ်"

    return re.sub(pattern, replace_currency, text, flags=re.I)


# ============================================================
# General numbers
# ============================================================

def normalize_numbers(text):
    """
    Convert only standalone numeric values.
    Identifiers have already been protected.
    """
    def replace_number(match):
        try:
            return number_to_myanmar(int(match.group(0)))
        except (ValueError, TypeError):
            return match.group(0)

    return re.sub(
        r"(?<![\w.,])\d+(?![\w.,])",
        replace_number,
        text,
    )


# ============================================================
# Main normalizer
# ============================================================

def normalize_for_myanmar_tts(text):
    """
    Normalize mixed Myanmar + English railway chatbot text
    for my-MM-NilarNeural.

    Order:
        1. Protect identifiers
        2. Normalize dates
        3. Normalize time
        4. Normalize currency
        5. Normalize month names
        6. Normalize railway terminology
        7. Normalize AM / PM
        8. Normalize general numbers
        9. Restore identifiers
        10. Normalize whitespace
    """
    s = str(text)

    # Keep arrow meaning natural for Myanmar speech.
    s = s.replace("→", "မှ")

    s, protected = protect_identifiers(s)

    s = normalize_date(s)
    s = normalize_time(s)
    s = normalize_currency(s)
    s = normalize_month_names(s)
    s = normalize_railway_terms(s)
    s = normalize_ampm(s)
    s = normalize_numbers(s)

    s = restore_identifiers(s, protected)
    s = normalize_alphabet_for_tts(s)
    s = re.sub(r"\s+", " ", s).strip()

    return s
