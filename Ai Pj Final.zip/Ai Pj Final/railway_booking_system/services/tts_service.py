
import asyncio
import hashlib
import re
from pathlib import Path

import edge_tts

from .text_normalizer import (
    booking_id_to_speech,
    normalize_for_myanmar_tts,
    phone_number_to_speech,
)




def prepare_tts_response(text: str) -> str:
    """
    Build the concise voice response.

    Seat availability screens may contain a long available-seat list and
    a seat-selection instruction. Those remain visible in the UI but are
    intentionally excluded from speech.
    """
    value = str(text)

    marker = "🟢 လွတ်နေသောခုံ"
    if marker in value:
        value = value.split(marker, 1)[0].rstrip()

    # The seat-selection instruction is also UI-only when it follows a
    # seat availability summary.
    if "ခုံနံပါတ်ကို Coach" in value and "💺" in value:
        value = value.split("ခုံနံပါတ်ကို Coach", 1)[0].rstrip()

    return value


def prepare_phone_numbers_for_tts(text: str) -> str:
    """Protect phone-number digits so the general number converter cannot
    turn them into သိန်း/သောင်း/ထောင် place-value speech."""
    placeholders = {}

    def repl(match):
        phone = match.group(1)
        token = f"__PHONE_{len(placeholders)}__"
        placeholders[token] = phone_number_to_speech(phone)
        return match.group(0).replace(phone, token)

    # Match phone-like digit strings after common Myanmar/English labels.
    pattern = re.compile(r"(?:ဖုန်း|phone|mobile|tel(?:ephone)?)\s*[:：-]?\s*([+]?\d[\d\s-]{6,}\d)", re.I)
    value = pattern.sub(repl, text)

    for token, spoken in placeholders.items():
        value = value.replace(token, spoken)
    return value


def prepare_booking_ids_for_tts(text: str) -> str:
    """Protect Booking ID values and replace them with character-by-character speech."""
    placeholders = {}

    def repl(match):
        booking_id = match.group(1)
        token = f"__BOOKING_ID_{len(placeholders)}__"
        placeholders[token] = booking_id_to_speech(booking_id)
        return match.group(0).replace(booking_id, token)

    pattern = re.compile(r"\b(MLY-[A-Z0-9]{8})\b", re.I)
    value = pattern.sub(repl, str(text))
    for token, spoken in placeholders.items():
        value = value.replace(token, spoken)
    return value


# ============================================================
# Paths
# ============================================================

ROOT = Path(__file__).resolve().parents[1]

CACHE = ROOT / ".tts_cache"
CACHE.mkdir(parents=True, exist_ok=True)


# ============================================================
# Myanmar Edge-TTS Voice
# ============================================================

VOICE = "my-MM-NilarNeural"


# ============================================================
# Cache filename
# ============================================================

def _safe_name(text: str) -> str:
    """
    Generate a unique cache filename from normalized text.
    """

    return (
        hashlib.sha256(
            text.encode("utf-8")
        ).hexdigest()
        + ".mp3"
    )


# ============================================================
# Generate speech
# ============================================================

async def _generate(text: str, path: Path):
    """
    Generate Myanmar speech using Edge-TTS.
    """

    communicate = edge_tts.Communicate(
        text=text,
        voice=VOICE
    )

    await communicate.save(str(path))


# ============================================================
# Run async function safely
# ============================================================

def _run_async(coro):
    """
    Run an async coroutine safely.

    Normal Python:
        asyncio.run()

    If an event loop is already running,
    create a temporary loop in another thread.
    """

    try:
        asyncio.get_running_loop()
    except RuntimeError:
        # No running event loop
        return asyncio.run(coro)

    # Running event loop exists
    import threading

    result = []
    error = []

    def runner():
        try:
            result.append(asyncio.run(coro))
        except Exception as e:
            error.append(e)

    thread = threading.Thread(target=runner)
    thread.start()
    thread.join()

    if error:
        raise error[0]

    return result[0] if result else None


# ============================================================
# Main TTS Function
# ============================================================

def synthesize(text: str):
    """
    Convert input text into Myanmar speech.

    Returns:
        audio_bytes: MP3 audio bytes
        normalized: text after TTS normalization
    """

    # --------------------------------------------------------
    # 1. Normalize text
    #
    # Examples:
    #
    # AM
    # -> မနက်
    #
    # PM
    # -> ညနေ
    #
    # September
    # -> စက်တင်ဘာလ
    #
    # 20
    # -> နှစ်ဆယ်
    #
    # 21
    # -> နှစ်ဆယ့်တစ်
    #
    # 25000 ကျပ်
    # -> နှစ်သောင်းငါးထောင် ကျပ်
    # --------------------------------------------------------

    prepared = prepare_tts_response(text)
    prepared = prepare_phone_numbers_for_tts(prepared)
    prepared = prepare_booking_ids_for_tts(prepared)
    normalized = normalize_for_myanmar_tts(prepared)

    # --------------------------------------------------------
    # 2. Create cache path
    # --------------------------------------------------------

    path = CACHE / _safe_name(normalized)

    # --------------------------------------------------------
    # 3. Generate only if not cached
    # --------------------------------------------------------

    if not path.exists():

        _run_async(
            _generate(
                normalized,
                path
            )
        )

    # --------------------------------------------------------
    # 4. Return MP3 bytes + normalized text
    # --------------------------------------------------------

    return path.read_bytes(), normalized

