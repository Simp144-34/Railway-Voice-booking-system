import re
from datetime import date, timedelta
from .booking_service import (
    allowed_destinations,
    booking_window,
    cancel_booking,
    CLASS_FIRST,
    CLASS_UPPER,
    create_booking,
    fare,
    find_booking,
    seats_for_journey,
    trip_times,
    validate_customer,
)
from .inquiry_service import (
    OPERATION_LABELS,
    answer as inquiry_answer,
    operation_prompt,
)

# ============================================================
# Operation constants
# ============================================================

BOOKING = "BOOKING"
CANCEL_BOOKING = "CANCEL_BOOKING"
CHECK_BOOKING = "CHECK_BOOKING"
TRAIN_INFO = "TRAIN_INFO"

OPERATIONS = (BOOKING, CANCEL_BOOKING, CHECK_BOOKING, TRAIN_INFO)


MM_DIGITS = str.maketrans("၀၁၂၃၄၅၆၇၈၉", "0123456789")

DEST_ALIASES = {
    "ပေါင်": "ပေါင်",
    "paung": "ပေါင်",
    "သထုံ": "သထုံ",
    "thaton": "သထုံ",
    "ကျိုက်ထို": "ကျိုက်ထို",
    "kyaikto": "ကျိုက်ထို",
    "kyaikhto": "ကျိုက်ထို",
    "သိမ်ဇရပ်": "သိမ်ဇရပ်",
    "thein za yat": "သိမ်ဇရပ်",
    "thein zayat": "သိမ်ဇရပ်",
    "ပဲခူး": "ပဲခူး",
    "bago": "ပဲခူး",
    "တိုးကြောင်ကလေး": "တိုးကြောင်ကလေး",
    "toe kyaung kalay": "တိုးကြောင်ကလေး",
    "toe kyaung": "တိုးကြောင်ကလေး",
    "ရန်ကုန်": "ရန်ကုန်",
    "yangon": "ရန်ကုန်",
}

NUMBER_WORDS = {
    "one": 1,
    "two": 2,
    "three": 3,
    "four": 4,
    "five": 5,
    "six": 6,
    "seven": 7,
    "eight": 8,
    "တစ်": 1,
    "တစ်ခုံ": 1,
    "နှစ်": 2,
    "နှစ်ခုံ": 2,
    "သုံး": 3,
    "လေး": 4,
    "ငါး": 5,
    "ခြောက်": 6,
    "ခုနစ်": 7,
    "ရှစ်": 8,
}


def norm(s):
    return s.strip().lower().translate(MM_DIGITS)


def initial_state(active_operation=None):
    """Create clean conversation state while preserving the selected operation."""
    return {
        "active_operation": active_operation,
        "step": "start",
        "b": {},
    }


def operation_label(operation):
    return OPERATION_LABELS.get(operation, operation)


def operation_start_message(operation):
    """Return the first prompt for the selected operation."""
    if operation == BOOKING:
        return "🎫 Booking လုပ်ပေးပါမယ်။ ခရီးသွားမည့်ရက်ကို ပြောပေးပါ။"
    if operation == CANCEL_BOOKING:
        return "❌ Booking Cancel လုပ်ပေးပါမယ်။ Booking ID / Reference ကို ပြောပေးပါ။"
    if operation == CHECK_BOOKING:
        return "🔎 Booking စစ်ပေးပါမယ်။ Booking ID / Reference ကို ပြောပေးပါ။"
    if operation == TRAIN_INFO:
        return "❓ ရထားအကြောင်း သိချင်တာကို မေးပေးပါ။\nဥပမာ — ရထားဘယ်အချိန်ထွက်လဲ / ရန်ကုန်လက်မှတ်ခ ဘယ်လောက်လဲ"
    return operation_prompt()


def parse_date(text):
    t = norm(text)
    today, _ = booking_window()

    if any(x in t for x in ("today", "ယနေ့", "ဒီနေ့")):
        return today

    if any(x in t for x in ("tomorrow", "မနက်ဖြန်", "နက်ဖြန်")):
        return today + timedelta(days=1)

    m = re.search(r"(20\d{2})[-/.](\d{1,2})[-/.](\d{1,2})", t)
    if m:
        try:
            return date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            return None

    m = re.search(r"(\d{1,2})[-/.](\d{1,2})(?:[-/.](20\d{2}))?", t)
    if m:
        try:
            return date(
                int(m.group(3) or today.year),
                int(m.group(2)),
                int(m.group(1)),
            )
        except ValueError:
            return None

    return None


def parse_destination(text):
    t = norm(text)
    for key, value in DEST_ALIASES.items():
        if key in t:
            return value
    return None


def destination_id(name):
    for row in allowed_destinations():
        if row["station_name"] == name:
            return row["station_id"]
    return None


def parse_class(text):
    t = norm(text)
    if any(x in t for x in ("ပထမ", "first", "1st")):
        return CLASS_FIRST
    if any(x in t for x in ("အထက်", "upper", "second", "2nd")):
        return CLASS_UPPER
    return None


def parse_count(text):
    t = norm(text)
    m = re.search(r"(?<!\d)([1-8])(?!\d)", t)
    if m:
        return int(m.group(1))

    for word, n in NUMBER_WORDS.items():
        if word in t:
            return n

    return None


def parse_yes_no(text):
    t = norm(text)
    yes = ("yes", "ဟုတ်", "အတည်ပြု", "confirm", "အိုကေ", "ok", "လုပ်မယ်")
    no = ("no", "မဟုတ်", "မလုပ်", "မလုပ်တော့", "မလုပ်ဘူး", "ဖျက်")

    if any(x in t for x in yes):
        return True
    if any(x in t for x in no):
        return False
    return None


def parse_reference(text):
    m = re.search(r"MLY-[A-Z0-9]{8}", text, re.I)
    return m.group(0).upper() if m else text.strip().upper()


def parse_seats(text, rows):
    t = norm(text).replace("coach", "").replace("ခုံ", " ")
    found = []

    # Supports:
    # 1-A1, Coach 1-A1, 1 A1, A1, B3
    patterns = re.findall(
        r"(?:(\d+)\s*[-/]?\s*)?([a-d])\s*[- ]?\s*(\d{1,2})",
        t,
        re.I,
    )

    for coach, row, num in patterns:
        coach_no = int(coach) if coach else None

        for r in rows:
            if (
                r["seat_row"].lower() == row.lower()
                and int(r["seat_number"]) == int(num)
            ):
                if coach_no is None or int(r["coach_number"]) == coach_no:
                    found.append(int(r["seat_id"]))
                    break

    return list(dict.fromkeys(found))


class RailwayChatbot:
    """
    Operation-controlled railway chatbot.

    IMPORTANT:
    active_operation is selected by the UI radio button.
    User text is used only to extract data/entities INSIDE
    the selected operation. It can never change the operation.
    """

    def __init__(self, state=None):
        self.s = state if state is not None else initial_state()

        # Backward compatibility for old state objects that used "mode".
        if "active_operation" not in self.s:
            old_mode = self.s.get("mode")
            old_map = {
                "book": BOOKING,
                "cancel": CANCEL_BOOKING,
                "check": CHECK_BOOKING,
                "inquiry": TRAIN_INFO,
            }
            self.s["active_operation"] = old_map.get(old_mode)

        self.s.setdefault("step", "start")
        self.s.setdefault("b", {})

    @property
    def active_operation(self):
        return self.s.get("active_operation")

    def set_operation(self, operation):
        """
        Set the operation selected by the UI.

        Changing operation always clears operation-specific temporary
        state so booking data cannot leak into cancel/check/inquiry.
        """
        if operation not in OPERATIONS:
            raise ValueError(f"Unknown operation: {operation}")

        previous = self.s.get("active_operation")
        self.s.clear()
        self.s.update(initial_state(operation))

        return previous != operation

    def reset_flow(self):
        """Reset only the current operation's workflow state."""
        operation = self.s.get("active_operation")
        self.s.clear()
        self.s.update(initial_state(operation))

    def reset(self):
        """Backward-compatible alias: reset flow but keep selected operation."""
        self.reset_flow()

    def handle(self, text):
        raw = text.strip()
        if not raw:
            return [operation_prompt()]

        if any(x in norm(raw) for x in ("restart", "reset", "အစကနေ", "ပြန်စ")):
            self.reset_flow()
            return [
                f"အစကနေ ပြန်စပါမယ်။\nလက်ရှိ Operation: {operation_label(self.active_operation)}",
                operation_start_message(self.active_operation),
            ]

        # --------------------------------------------------------
        # HARD RULE:
        # There is NO operation routing from user text.
        #
        # The UI-selected active_operation always decides the flow.
        # The optional hint below only explains how to change the
        # operation; it NEVER changes self.s["active_operation"].
        # --------------------------------------------------------

        operation = self.active_operation
        t = norm(raw)

        hint = self.operation_change_hint(operation, t)
        if hint:
            return [hint]

        if operation == BOOKING:
            return self.handle_book(raw, norm(raw))

        if operation == CANCEL_BOOKING:
            return self.handle_cancel(raw, norm(raw))

        if operation == CHECK_BOOKING:
            return self.handle_check(raw, norm(raw))

        if operation == TRAIN_INFO:
            return self.handle_inquiry(raw, norm(raw))

        return [operation_prompt()]

    @staticmethod
    def operation_change_hint(operation, text):
        """
        Detect only a clear request for a DIFFERENT operation so the
        chatbot can tell the user which radio option to select.

        This is NOT routing: active_operation is never changed here.
        """
        t = norm(text)

        if operation != BOOKING and any(
            x in t
            for x in (
                "booking အသစ်",
                "booking အသစ်လုပ်",
                "booking လုပ်ချင်",
                "booking လုပ်မယ်",
                "book ticket",
                "လက်မှတ်မှာချင်",
                "လက်မှတ်မှာယူချင်",
            )
        ):
            return (
                f"လက်ရှိ Operation က {operation_label(operation)} ဖြစ်ပါတယ်။\n"
                "Booking အသစ်လုပ်ချင်ရင် အပေါ်က "
                "🎫 Booking လုပ်မယ် ကို ရွေးပေးပါ။"
            )

        if operation == BOOKING and any(
            x in t for x in ("cancel booking", "booking cancel", "cancel လုပ်", "booking ဖျက်")
        ):
            return (
                "လက်ရှိ Operation က 🎫 Booking လုပ်မယ် ဖြစ်ပါတယ်။\n"
                "Booking Cancel လုပ်ချင်ရင် အပေါ်က "
                "❌ Booking Cancel လုပ်မယ် ကို ရွေးပေးပါ။"
            )

        if operation == BOOKING and any(
            x in t for x in ("check booking", "booking check", "booking စစ်")
        ):
            return (
                "လက်ရှိ Operation က 🎫 Booking လုပ်မယ် ဖြစ်ပါတယ်။\n"
                "Booking စစ်ချင်ရင် အပေါ်က "
                "🔎 Booking စစ်မယ် ကို ရွေးပေးပါ။"
            )

        if operation != CHECK_BOOKING and any(
            x in t for x in ("check booking", "booking check", "booking စစ်")
        ):
            return (
                f"လက်ရှိ Operation က {operation_label(operation)} ဖြစ်ပါတယ်။\n"
                "Booking စစ်ချင်ရင် အပေါ်က "
                "🔎 Booking စစ်မယ် ကို ရွေးပေးပါ။"
            )

        if operation != CANCEL_BOOKING and any(
            x in t for x in ("cancel booking", "booking cancel", "booking ဖျက်", "cancel လုပ်")
        ):
            return (
                f"လက်ရှိ Operation က {operation_label(operation)} ဖြစ်ပါတယ်။\n"
                "Booking Cancel လုပ်ချင်ရင် အပေါ်က "
                "❌ Booking Cancel လုပ်မယ် ကို ရွေးပေးပါ။"
            )

        return None

    def question_date(self):
        today, maxday = booking_window()
        return (
            "📅 ခရီးသွားမည့်ရက်ကို ပြောပေးပါ။\n"
            f"ဥပမာ — {today:%d/%m/%Y}။ "
            f"ယနေ့မှ {maxday:%d/%m/%Y} အထိ Booking ရပါတယ်။"
        )

    def route_text(self):
        return "၊ ".join(r["station_name"] for r in allowed_destinations())

    def handle_inquiry(self, raw, _t):
        result = inquiry_answer(raw)

        if result:
            # Keep TRAIN_INFO active so the user can ask another
            # railway question without selecting the operation again.
            self.reset_flow()
            return [
                result,
                "\nနောက်ထပ် ရထားအကြောင်း မေးနိုင်ပါတယ်။",
            ]

        return [
            "ရထားအချိန်စာရင်း၊ လက်မှတ်ခ၊ ခရီးကြာချိန်၊ VIP၊ "
            "အစားအသောက်၊ ဘူတာရောက်ချိန်တို့ကိုသာ မေးနိုင်ပါတယ်။"
        ]

    def handle_book(self, raw, _t):
        b, step = self.s["b"], self.s["step"]

        if step == "start":
            self.s["step"] = "date"
            return [self.question_date()]

        if step == "date":
            d = parse_date(raw)
            today, maxday = booking_window()

            if not d or not (today <= d <= maxday):
                return [self.question_date()]

            b["date"] = d.isoformat()
            self.s["step"] = "destination"

            return [
                "🚉 ထွက်ခွာဘူတာကို မော်လမြိုင်တစ်ခုတည်းအဖြစ် သတ်မှတ်ထားပါတယ်။\n"
                "သွားမည့်ဘူတာကို ပြောပေးပါ — " + self.route_text()
            ]

        if step == "destination":
            dest = parse_destination(raw)
            did = destination_id(dest) if dest else None

            if not dest or did is None:
                return [
                    "ဒီစနစ်မှာ Booking ကို မော်လမြိုင်ကနေသာ စတင်နိုင်ပါတယ်။\n"
                    "သွားမည့် downstream station ကို ရွေးပါ — " + self.route_text()
                ]

            b.update(destination=dest, destination_id=did)
            self.s["step"] = "class"

            return [
                f"✅ {dest} ကို သတ်မှတ်လိုက်ပါပြီ။ "
                "🎫 ပထမတန်း သို့မဟုတ် အထက်တန်း ဘယ် Class လိုချင်ပါသလဲ?",
                f"💰 မော်လမြိုင် → {dest} Fare: "
                f"ပထမတန်း {(fare(did, CLASS_FIRST) or 0):,.0f} ကျပ် | "
                f"အထက်တန်း {(fare(did, CLASS_UPPER) or 0):,.0f} ကျပ်",
            ]

        if step == "class":
            cls = parse_class(raw)

            if not cls:
                return [
                    "🎫 Class ကို ပထမတန်း (First Class) သို့မဟုတ် "
                    "အထက်တန်း (Upper Class) လို့ ပြောပေးပါ။"
                ]

            b["class"] = cls
            self.s["step"] = "count"

            return [
                f"✅ {cls} ရွေးပြီးပါပြီ။ "
                "🔢 ခုံအရေအတွက် ဘယ်နှစ်ခုံလိုချင်ပါသလဲ? (အများဆုံး ၈ ခုံ)"
            ]

        if step == "count":
            n = parse_count(raw)

            if not n or not 1 <= n <= 8:
                return [
                    "🔢 ခုံအရေအတွက်ကို ၁ မှ ၈ အတွင်း ပြောပေးပါ။\n"
                    "၅ နှစ်အောက်ကလေးများအတွက် ခုံယူရန်မလိုပါ"
                ]

            b["seat_count"] = n
            self.s["step"] = "seats"

            return [self.seat_status_message(b["date"], b["class"], n)]

        if step == "seats":
            # ALWAYS refresh from DB.
            _, rows = seats_for_journey(b["date"], b["class"])
            available = [dict(r) for r in rows if not r["occupied"]]

            ids = parse_seats(raw, available)
            requested_patterns = re.findall(
                r"(?:(\d+)\s*[-/]?\s*)?([a-d])\s*[- ]?\s*(\d{1,2})",
                norm(raw),
                re.I,
            )

            if requested_patterns and len(ids) < len(requested_patterns):
                return [
                    "❌ ရွေးထားတဲ့ခုံထဲမှာ မလွတ်တဲ့ခုံ သို့မဟုတ် မရှိတဲ့ခုံ "
                    "ပါနေပါတယ်။ လွတ်တဲ့ခုံကိုပဲ ပြန်ရွေးပေးပါ။",
                    self.seat_status_message(
                        b["date"], b["class"], b["seat_count"]
                    ),
                ]

            if len(ids) != b["seat_count"]:
                return [
                    f"လိုအပ်တာ {b['seat_count']} ခုံပါ။ "
                    f"သင်ရွေးထားတာ {len(ids)} ခုံပါ။",
                    self.seat_status_message(
                        b["date"], b["class"], b["seat_count"]
                    ),
                ]

            b["seats"] = ids
            self.s["step"] = "name"

            return [
                "✅ ရွေးထားတဲ့ခုံတွေကို ခုံအလွတ်ရှိ မရှိ စစ်ပြီးပါပြီ။\n"
                "👤 Booking ပြုလုပ်မည့်သူအမည်ကို ပြောပေးပါ။"
            ]

        if step == "name":
            if len(raw) < 2:
                return ["👤 အမည်ကို မှန်ကန်စွာ ပြောပေးပါ။"]

            b["name"] = raw
            self.s["step"] = "phone"
            return ["📱 ဖုန်းနံပါတ်ကို ပြောပေးပါ။"]

        if step == "phone":
            try:
                _, phone = validate_customer(b["name"], raw)
            except ValueError as e:
                return [f"{e}\n📱 ဖုန်းနံပါတ်ကို ထပ်ပြောပေးပါ။"]

            b["phone"] = phone
            self.s["step"] = "confirm"

            return [
                self.summary(),
                "အချက်အလက်အားလုံး မှန်ကန်ပါက "
                "✅ “အတည်ပြု” / “confirm” လို့ ပြောပေးပါ။ "
                "မမှန်ရင် “မလုပ်တော့” လို့ ပြောနိုင်ပါတယ်။",
            ]

        if step == "confirm":
            yn = parse_yes_no(raw)

            if yn is False:
                self.reset_flow()
                return ["Booking မလုပ်တော့ပါ။", operation_start_message(BOOKING)]

            if yn is not True:
                return [
                    "Booking ကို အတည်ပြုမလား? "
                    "✅ “အတည်ပြု” / “confirm” လို့ ပြောပေးပါ။"
                ]

            try:
                ref, rows, total = create_booking(
                    b["date"],
                    b["destination_id"],
                    b["class"],
                    b["seats"],
                    b["name"],
                    b["phone"],
                )
            except ValueError as e:
                return [
                    f"❌ Booking မအောင်မြင်ပါ။ {e}",
                    "⚠️ Confirm မလုပ်ခင် ခုံလွတ်/မလွတ်ကို "
                    "နောက်တစ်ကြိမ်စစ်ပေးပါမယ်။",
                ]

            seats = ", ".join(
                f"Coach {r['coach_number']}-{r['seat_row']}{r['seat_number']}"
                for r in rows
            )

            result = (
                "🎉 Booking အောင်မြင်ပါပြီ။\n"
                + self.format_booking_details(
                    {
                        "booking_reference": ref,
                        "booking_status": "CONFIRMED",
                        "journey_date": b["date"],
                        "departure_time": trip_times(b["destination_id"])[0],
                        "arrival_time": trip_times(b["destination_id"])[1],
                        "destination": b["destination"],
                        "class_type": b["class"],
                        "full_name": b["name"],
                        "phone": b["phone"],
                    },
                    rows,
                    total,
                )
                + "\nဒီ Booking ID ကို သိမ်းထားပါ။ Cancel/Check လုပ်ရာမှာ လိုအပ်ပါတယ်။"
            )

            self.reset_flow()
            return [result, operation_start_message(BOOKING)]

        return [self.question_date()]

    def seat_status_message(self, journey_date, class_type, needed):
        _, rows = seats_for_journey(journey_date, class_type)
        available = [dict(r) for r in rows if not r["occupied"]]
        occupied = [dict(r) for r in rows if r["occupied"]]

        coaches = {}
        for r in rows:
            coaches.setdefault(
                int(r["coach_number"]),
                {"a": 0, "o": 0},
            )

        for r in available:
            coaches[int(r["coach_number"])]["a"] += 1

        for r in occupied:
            coaches[int(r["coach_number"])]["o"] += 1

        lines = [
            f"💺 {needed} ခုံ ရွေးပါမယ်။",
            "🟢 ခုံလွတ်/🔴 ခုံမလွတ် အခြေအနေကို စစ်ထားပါတယ်။",
        ]

        lines += [
            f"Coach {n}: 🟢 {v['a']} ခုံလွတ် | 🔴 {v['o']} ခုံမလွတ်"
            for n, v in sorted(coaches.items())
        ]

        preview = ", ".join(
            f"Coach {r['coach_number']}-{r['seat_row']}{r['seat_number']}"
            for r in available[:30]
        )

        if preview:
            lines.append(
                "🟢 လွတ်နေသောခုံ (ဥပမာ): "
                + preview
                + (" …" if len(available) > 30 else "")
            )

        lines.append(
            "ခုံနံပါတ်ကို Coach 1-A1, A1, B3 စသဖြင့် ပြောပေးပါ။"
        )

        return "\n".join(lines)

    def summary(self):
        b = self.s["b"]
        _, rows = seats_for_journey(b["date"], b["class"])
        chosen = [r for r in rows if r["seat_id"] in b["seats"]]
        total = (fare(b["destination_id"], b["class"]) or 0) * len(chosen)

        seats = ", ".join(
            f"Coach {r['coach_number']}-{r['seat_row']}{r['seat_number']}"
            for r in chosen
        )

        departure_time, arrival_time = trip_times(b["destination_id"])

        return (
            "🧾 Booking Summary\n"
            f"ရက်စွဲ: {date.fromisoformat(b['date']):%d/%m/%Y}\n"
            f"ထွက်ခွာချိန်: {departure_time}\n"
            f"ရောက်ရှိချိန်: {arrival_time}\n"
            f"ခရီးစဉ်: မော်လမြိုင် → {b['destination']}\n"
            f"Class: {b['class']}\n"
            f"ခုံ: {seats}\n"
            f"အမည်: {b['name']}\n"
            f"ဖုန်း: {b['phone']}\n"
            f"စုစုပေါင်း: {total:,.0f} ကျပ်"
        )

    def format_booking_details(self, r, rows, total=None):
        """Render one consistent booking detail form for success/check/cancel."""
        seats = ", ".join(
            f"Coach {z['coach_number']}-{z['seat_row']}{z['seat_number']}"
            for z in rows
        )
        status = r.get("booking_status", "CONFIRMED")
        status_text = (
            "CONFIRMED / အတည်ပြုထားသည်"
            if status == "CONFIRMED"
            else "CANCELLED / ပယ်ဖျက်ပြီး"
        )
        total_line = ""
        if total is not None:
            total_line = f"\nစုစုပေါင်း: {total:,.0f} ကျပ်"
        name_line = f"\nအမည်: {r['full_name']}" if r.get("full_name") else ""
        phone_line = f"\nဖုန်း: {r['phone']}" if r.get("phone") else ""
        return (
            f"Booking ID: {r['booking_reference']}\n"
            f"Status: {status_text}\n"
            f"ရက်စွဲ: {date.fromisoformat(r['journey_date']):%d/%m/%Y}\n"
            f"ထွက်ခွာချိန်: {r['departure_time']}\n"
            f"ရောက်ရှိချိန်: {r['arrival_time']}\n"
            f"ခရီးစဉ်: မော်လမြိုင် → {r['destination']}\n"
            f"Class: {r['class_type']}\n"
            f"ခုံ: {seats}"
            f"{name_line}{phone_line}{total_line}"
        )

    def handle_check(self, raw, _t):
        if self.s["step"] == "start":
            self.s["step"] = "reference"

        if self.s["step"] != "reference":
            return ["Booking ID / Reference ကို ပြောပေးပါ။"]

        ref = parse_reference(raw)
        rows = find_booking(ref)

        if not rows:
            return [
                "❌ Booking ID မတွေ့ပါ။ "
                "ဥပမာ MLY-AB12CD34 ပုံစံနဲ့ ပြန်ပြောပေးပါ။"
            ]

        r = dict(rows[0])
        total = (fare(r["destination_station_id"], r["class_type"]) or 0) * len(rows)
        result = (
            "🔎 Booking အချက်အလက်\n"
            + self.format_booking_details(r, rows, total)
        )

        self.reset_flow()
        return [result, "🔎 နောက်ထပ် Booking စစ်လိုပါက Booking ID ကို ပြောပေးပါ။"]

    def handle_cancel(self, raw, _t):
        if self.s["step"] == "start":
            self.s["step"] = "reference"

        if self.s["step"] == "reference":
            ref = parse_reference(raw)
            rows = find_booking(ref)

            if not rows:
                return [
                    "❌ Booking ID မတွေ့ပါ။ "
                    "ဥပမာ MLY-AB12CD34 ပုံစံနဲ့ ပြန်ပြောပေးပါ။"
                ]

            active = [dict(r) for r in rows if r["booking_status"] == "CONFIRMED"]

            if not active:
                self.reset_flow()
                return [
                    "ဒီ Booking ကို Cancel လုပ်ပြီးသားပါ။",
                    "❌ နောက်ထပ် Cancel လုပ်လိုသော Booking ID ကို ပြောပေးပါ။",
                ]

            self.s["b"].update(ref=active[0]["booking_reference"])
            self.s["step"] = "confirm_cancel"

            r = active[0]
            total = (fare(r["destination_station_id"], r["class_type"]) or 0) * len(active)
            details = self.format_booking_details(r, active, total)

            return [
                "🔎 Booking တွေ့ပါပြီ။\n" + details,
                "⚠️ ဒီ Booking ရဲ့ ခုံအားလုံးကို ပြန်လွတ်စေမှာဖြစ်ပါတယ်။ "
                "Cancel အတည်ပြုမလား? “အတည်ပြု” လို့ ပြောပါ။",
            ]

        if self.s["step"] == "confirm_cancel":
            yn = parse_yes_no(raw)

            if yn is False:
                self.reset_flow()
                return [
                    "Cancel မလုပ်တော့ပါ။",
                    "❌ နောက်ထပ် Cancel လုပ်လိုသော Booking ID ကို ပြောပေးပါ။",
                ]

            if yn is not True:
                return [
                    "Cancel ကို အတည်ပြုမလား? "
                    "“အတည်ပြု” / “confirm” လို့ ပြောပေးပါ။"
                ]

            ref = self.s["b"]["ref"]

            # Fetch the booking again immediately before the UPDATE so the
            # success form always has the exact database values. This also
            # fixes the old bug where `r` was referenced before assignment.
            rows = find_booking(ref)
            active = [dict(r) for r in rows if r["booking_status"] == "CONFIRMED"]
            if not active:
                self.reset_flow()
                return ["❌ ဒီ Booking ကို Cancel လုပ်လို့မရတော့ပါ။ Booking status ကို ပြန်စစ်ပေးပါ။"]

            r = active[0]
            total = (fare(r["destination_station_id"], r["class_type"]) or 0) * len(active)

            try:
                n = cancel_booking(ref)
            except ValueError as e:
                self.reset_flow()
                return [f"❌ {e}"]

            # Re-read after UPDATE to verify the database state.
            after = find_booking(ref)
            if any(x["booking_status"] != "CANCELLED" for x in after):
                self.reset_flow()
                return ["❌ Cancellation database update မပြည့်စုံပါ။ Booking status ကို ပြန်စစ်ပေးပါ။"]

            cancelled_details = (
                "❌ Booking Cancel အောင်မြင်ပါပြီ။\n"
                + self.format_booking_details(
                    r,
                    active,
                    total,
                ).replace(
                    "Status: CONFIRMED / အတည်ပြုထားသည်",
                    "Status: CANCELLED / ပယ်ဖျက်ပြီး",
                    1,
                )
                + f"\n{n} ခုံ ပြန်လွတ်သွားပါပြီ။"
            )
            self.reset_flow()
            return [
                cancelled_details,
                "❌ နောက်ထပ် Cancel လုပ်လိုသော Booking ID ကို ပြောပေးပါ။",
            ]

        return ["Booking ID / Reference ကို ပြောပေးပါ။"]

